/* Load feed media near the viewport; keep signing and decoder work bounded. */
let disposeFeedMedia = () => {};
function observeFeedMedia(posts, root) {
  disposeFeedMedia();
  let disposed = false, active = 0;
  const jobs = new Map(), queue = [], nearby = new Set(), started = new Set();
  const elements = [];
  for (const post of posts) {
    const element = document.getElementById("media-" + post.id);
    if (element) {
      jobs.set(element, post);
      elements.push(element);
    }
  }
  function pump() {
    while (!disposed && active < 3 && queue.length) {
      const element = queue.shift();
      if (
        !element.isConnected || !nearby.has(element) || started.has(element)
      ) continue;
      started.add(element);
      active++;
      element.preload = "metadata";
      Promise.resolve().then(() => loadPostMedia(jobs.get(element)))
        .catch(() => {})
        .finally(() => {
          active--;
          pump();
        });
    }
  }
  function pauseOthers(event) {
    for (const element of elements) {
      if (element !== event.target) element.pause();
    }
  }
  function pauseHidden() {
    if (document.hidden) { for (const element of elements) element.pause(); }
  }
  const fallback = !("IntersectionObserver" in window);
  const prefetch = fallback ? null : new IntersectionObserver((entries) => {
    for (const { target, isIntersecting } of entries) {
      if (isIntersecting) {
        nearby.add(target);
        if (!started.has(target)) queue.push(target);
      } else nearby.delete(target);
    }
    pump();
  }, { root, rootMargin: navigator.connection?.saveData ? "0px" : "500px" });
  const playback = fallback ? null : new IntersectionObserver((entries) => {
    for (const { target, isIntersecting } of entries) {
      if (!isIntersecting) target.pause();
    }
  }, { root });
  for (const element of elements) {
    element.addEventListener("play", pauseOthers);
    if (prefetch) {
      prefetch.observe(element);
      playback.observe(element);
    } else {
      // Preserve playback on older browsers with the same concurrency limit.
      nearby.add(element);
      queue.push(element);
    }
  }
  if (fallback) pump();
  document.addEventListener("visibilitychange", pauseHidden);
  disposeFeedMedia = () => {
    disposed = true;
    queue.length = 0;
    prefetch?.disconnect();
    playback?.disconnect();
    document.removeEventListener("visibilitychange", pauseHidden);
    for (const element of elements) {
      element.removeEventListener("play", pauseOthers);
      element.pause();
    }
  };
}
