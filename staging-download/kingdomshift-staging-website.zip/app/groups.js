/* Member groups use bounded, rate-limited database RPCs; no client role grants. */
NAV_ITEMS.push({
  id: "groups",
  icon: "👥",
  label: "Groups",
  section: "COMMUNITY",
});
const renderBeforeGroups = render;
render = function () {
  if (!S.subPage && S.tab === "groups") {
    return renderGroups(document.getElementById("page"));
  }
  return renderBeforeGroups();
};
async function renderGroups(p) {
  const url = new URL(location.href), selected = url.searchParams.get("group");
  if (S.user && validId(selected)) {
    url.searchParams.delete("group");
    url.searchParams.delete("post");
    history.replaceState(null, "", url);
    return openGroup(selected);
  }
  const ownPage = ++S.groupPage || (S.groupPage = 1);
  p.innerHTML =
    '<div class="page-hdr"><h1 class="page-title">Groups</h1><p>Join a community to read and share member posts.</p><button class="btn btn-teal" onclick="createGroupDialog()">Create group</button></div><div id="group-directory" class="content-list" role="status">Loading groups…</div>';
  const target = document.getElementById("group-directory");
  if (!S.user) {
    target.textContent = "Sign in to join groups.";
    return;
  }
  try {
    const { data, error } = await sb.from("community_groups").select(
      "id,owner_id,title,description",
    ).order("created_at", { ascending: false }).limit(40);
    if (error) throw error;
    if (!target.isConnected || S.groupPage !== ownPage) return;
    target.innerHTML = (data || []).map((group) =>
      `<article class="content-card"><h2>${escape(group.title)}</h2><p>${
        escape(group.description)
      }</p><button class="btn btn-glass" onclick="openGroup(${
        idArg(group.id)
      })">Open group</button></article>`
    ).join("") || "<p>No groups yet. Create the first community.</p>";
  } catch {
    if (target.isConnected) {
      target.textContent = "Groups could not load. Please try again later.";
    }
  }
}
function createGroupDialog() {
  openDialog(
    "Create group",
    `<form id="group-create-form">${
      field("Group name", "group-title", "text", 'required maxlength="100"')
    }<label class="label" for="group-description">Description</label><textarea class="input" id="group-description" maxlength="2000"></textarea><p role="status" id="form-status"></p><button class="btn btn-teal" type="submit">Create group</button></form>`,
  );
  document.getElementById("group-create-form").onsubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const button = form.querySelector('[type="submit"]');
    busy(button, true);
    try {
      const id = await call("create_community_group", {
        group_title: document.getElementById("group-title").value.trim(),
        group_description: document.getElementById("group-description").value
          .trim(),
      });
      document.getElementById("customer-dialog").close();
      await openGroup(id);
    } catch (error) {
      formStatus(error.message);
    } finally {
      busy(button, false);
    }
  };
}
async function openGroup(id) {
  if (!validId(id)) return;
  const p = document.getElementById("page");
  const request = ++S.groupPage || (S.groupPage = 1);
  p.innerHTML = '<p role="status">Loading group…</p>';
  try {
    const { data: group, error } = await sb.from("community_groups").select(
      "id,owner_id,title,description",
    ).eq("id", id).maybeSingle();
    if (error || !group) throw new Error("This group is unavailable.");
    const { data: membership, error: memberError } = await sb.from(
      "community_group_members",
    ).select("user_id,status").eq("group_id", id).eq("user_id", S.user.id)
      .maybeSingle();
    if (memberError) throw memberError;
    if (S.groupPage !== request || S.tab !== "groups") return;
    const member = membership?.status === "active";
    const owner = group.owner_id === S.user.id;
    p.innerHTML =
      `<div class="page-hdr"><button class="btn btn-glass" onclick="navigate('groups')">Back to groups</button><h1 class="page-title">${
        escape(group.title)
      }</h1><p>${escape(group.description)}</p>${
        !owner
          ? `<button class="btn btn-glass" id="group-membership">${
            member ? "Leave group" : "Join group"
          }</button>`
          : ""
      }</div><div id="group-content" class="content-list"></div>`;
    const membershipButton = document.getElementById("group-membership");
    if (membershipButton) {
      membershipButton.onclick = async () => {
        busy(membershipButton, true);
        try {
          await call("join_community_group", { target: id, joining: !member });
          await openGroup(id);
        } catch (error) {
          actionError(error);
          busy(membershipButton, false);
        }
      };
    }
    const content = document.getElementById("group-content");
    if (!member) {
      content.textContent = "Join this group to read and share posts.";
      return;
    }
    content.innerHTML =
      '<form id="group-post-form"><label class="label" for="group-post-body">Write a post</label><textarea class="input" id="group-post-body" required maxlength="4000"></textarea><button class="btn btn-teal" type="submit">Post to group</button><p id="group-post-status" role="status"></p></form><div id="group-post-list"></div><div id="group-member-list"></div>';
    document.getElementById("group-post-form").onsubmit = async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      if (!form.reportValidity()) return;
      const button = form.querySelector('[type="submit"]');
      busy(button, true);
      try {
        await call("post_to_community_group", {
          target: id,
          content: document.getElementById("group-post-body").value.trim(),
        });
        await openGroup(id);
      } catch (error) {
        document.getElementById("group-post-status").textContent =
          error.message;
        busy(button, false);
      }
    };
    const { data: posts, error: postError } = await sb.from(
      "community_group_posts",
    ).select("id,user_id,body,created_at").eq("group_id", id).order(
      "created_at",
      { ascending: false },
    ).limit(50);
    if (S.groupPage !== request || S.tab !== "groups") return;
    const list = document.getElementById("group-post-list");
    if (postError) {
      list.textContent = "Posts could not load. Please try again.";
      return;
    }
    list.innerHTML = (posts || []).map((post) =>
      `<article class="content-card"><p>${
        escape(post.body)
      }</p><button class="btn btn-glass" onclick="reportGroupPost(${
        idArg(id)
      },${idArg(post.id)})">Report</button>${
        owner || post.user_id === S.user.id || S.profile?.role === "admin"
          ? `<button class="btn btn-glass" onclick="removeGroupPost(${
            idArg(id)
          },${idArg(post.id)})">Remove post</button>`
          : ""
      }</article>`
    ).join("") || "<p>No posts yet.</p>";
    if (owner) {
      const { data: members, error: membersError } = await sb.from(
        "community_group_members",
      ).select("user_id,status").eq("group_id", id).limit(100);
      if (S.groupPage !== request || membersError) {
        return;
      }
      document.getElementById("group-member-list").innerHTML =
        "<h2>Manage members</h2>" + (members || []).filter((row) =>
          row.user_id !== S.user.id
        ).map((row) =>
          `<p>${
            escape(row.user_id)
          } <button class="btn btn-glass" onclick="moderateGroup(${idArg(id)},${
            idArg(row.user_id)
          },${row.status !== "banned"})">${
            row.status === "banned"
              ? "Restore membership"
              : "Restrict membership"
          }</button></p>`
        ).join("");
    }
  } catch (error) {
    if (S.groupPage === request && S.tab === "groups") {
      p.innerHTML = `<p role="status">${
        escape(error.message || "Group could not load.")
      }</p>`;
    }
  }
}
async function removeGroupPost(group, post) {
  if (!confirm("Remove this post?")) return;
  try {
    await call("remove_community_group_post", { post_id: post });
    await openGroup(group);
  } catch (error) {
    actionError(error);
  }
}
async function moderateGroup(group, member, banning) {
  if (
    !confirm(
      banning
        ? "Restrict this member from the group?"
        : "Restore this membership?",
    )
  ) return;
  try {
    await call("moderate_community_group", {
      target: group,
      member_id: member,
      banning,
    });
    await openGroup(group);
  } catch (error) {
    actionError(error);
  }
}
function reportGroupPost(group, post) {
  // Reuse the platform's private, prioritized safety reporting workflow.
  navigate("safe");
  setTimeout(() => {
    const input = document.getElementById("report-url");
    if (input) {
      input.value =
        new URL("?group=" + group + "&post=" + post + "#groups", location.href)
          .href;
    }
  }, 0);
}
